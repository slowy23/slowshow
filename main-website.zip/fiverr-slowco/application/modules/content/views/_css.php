<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="<?= CSS;?>/style.css">
