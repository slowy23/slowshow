<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width">
<?php //$this->load->view("content/__favicon"); ?>
<title>Spencer Lowy</title>
<meta name="title" content="Seller Dashboard | Sodai.xyz">
<meta name="description" content="Sodai Seller Dashboard">
<meta property="og:title" content="Seller Dashboard | Sodai.xyz">
<meta property="og:image" content="<?= IMG; ?>/logo-og.jpg">
<meta name="author" content="Anup Kumer Paul">